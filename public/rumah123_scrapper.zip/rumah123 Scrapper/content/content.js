/**
 * Content Script for Rumah123 Scraper
 * Runs on rumah123.com pages to extract property data
 * Updated to match actual HTML structure
 */

// Multiple possible card selectors - trying different patterns
const CARD_SELECTORS = [
    '[data-test-id^="srp-listing-card-"]',
    '[data-test-id^="viewport-property-card-"]',
    '.property-card',
    '[class*="property-card"]',
    'article[data-test-id]',
    'div[data-test-id*="listing"]'
];

// State
let isScrapingActive = false;

/**
 * Clean and trim string
 */
function safe(s) {
    return (s || '').replace(/\u200b/g, '').trim();
}

/**
 * Convert relative time text to actual date
 */
function convertRelativeTimeToDate(text) {
    if (!text) return '';

    const now = new Date();
    const match = text.toLowerCase().match(/(\d+)\s*(menit|jam|hari|minggu|bulan|tahun)/);

    if (match) {
        const number = parseInt(match[1]);
        const unit = match[2];
        let date = new Date(now);

        switch (unit) {
            case 'menit': date.setMinutes(date.getMinutes() - number); break;
            case 'jam': date.setHours(date.getHours() - number); break;
            case 'hari': date.setDate(date.getDate() - number); break;
            case 'minggu': date.setDate(date.getDate() - (number * 7)); break;
            case 'bulan': date.setMonth(date.getMonth() - number); break;
            case 'tahun': date.setFullYear(date.getFullYear() - number); break;
            default: return text;
        }

        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    return text;
}

/**
 * Convert price text to numeric rupiah format
 */
function convertPriceToRupiah(text) {
    if (!text) return text;

    const textLower = text.toLowerCase();
    const numberMatch = text.match(/(\d+(?:[.,]\d+)?)/);

    if (!numberMatch) return text;

    const numberStr = numberMatch[1].replace(',', '.');
    const number = parseFloat(numberStr);

    if (isNaN(number)) return text;

    let amount;

    if (textLower.includes('miliar') || textLower.includes('milyar')) {
        amount = Math.round(number * 1000000000);
    } else if (textLower.includes('juta')) {
        amount = Math.round(number * 1000000);
    } else if (textLower.includes('ribu') || textLower.includes('rb')) {
        amount = Math.round(number * 1000);
    } else {
        amount = Math.round(number);
    }

    const formatted = 'Rp ' + amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return formatted;
}

/**
 * Find all property cards using multiple selectors
 */
function findPropertyCards() {
    for (const selector of CARD_SELECTORS) {
        const cards = document.querySelectorAll(selector);
        if (cards.length > 0) {
            console.log(`[Rumah123 Scraper] Found ${cards.length} cards using selector: ${selector}`);
            return cards;
        }
    }

    // Try to find any div that looks like a property card
    const allDivs = document.querySelectorAll('div[data-test-id]');
    const propertyDivs = Array.from(allDivs).filter(div => {
        const testId = div.getAttribute('data-test-id') || '';
        return testId.includes('listing') || testId.includes('property') || testId.includes('card');
    });

    if (propertyDivs.length > 0) {
        console.log(`[Rumah123 Scraper] Found ${propertyDivs.length} cards using data-test-id pattern`);
        return propertyDivs;
    }

    console.log('[Rumah123 Scraper] No cards found with any selector');
    return [];
}

/**
 * Extract data from a single card element
 */
function extractCardData(card) {
    const data = {
        judul: '',
        url_properti: '',
        harga_idr: '',
        cicilan_20_tahun: '',
        cicilan_15_tahun: '',
        kamar_tidur: null,
        kamar_mandi: null,
        luas_bangunan_m2: null,
        luas_tanah_m2: null,
        lokasi: '',
        gambar: '',
        tanggal_terbit: ''
    };

    try {
        // Extract title from various possible elements
        const titleSelectors = [
            'h2[data-testid*="url"]',
            'h2[data-test-id*="title"]',
            'h2 a',
            'h2',
            'a[title]',
            '[class*="title"]'
        ];

        for (const sel of titleSelectors) {
            const el = card.querySelector(sel);
            if (el) {
                data.judul = safe(el.innerText || el.textContent || el.getAttribute('title') || '');
                if (data.judul) break;
            }
        }

        // Extract URL from links
        const linkSelectors = [
            'a[href*="/properti/"]',
            'a[href*="/perumahan-baru/"]',
            'a[href*="/jual/"]',
            'a[href*="/sewa/"]',
            'a[href]'
        ];

        for (const sel of linkSelectors) {
            const el = card.querySelector(sel);
            if (el) {
                const href = el.getAttribute('href');
                if (href && !href.startsWith('javascript') && href !== '#') {
                    data.url_properti = href.startsWith('/') ? `https://www.rumah123.com${href}` : href;
                    break;
                }
            }
        }

        // Extract price - look for price patterns
        const pricePatterns = [
            /Rp\s*[\d.,]+\s*(Miliar|Milyar|Juta|Ribu)?/gi
        ];

        const priceSelectors = [
            '[data-testid*="price"]',
            '[data-test-id*="price"]',
            '[class*="price"]',
            'span',
            'p'
        ];

        for (const sel of priceSelectors) {
            const elements = card.querySelectorAll(sel);
            for (const el of elements) {
                const text = el.innerText || el.textContent || '';
                if (text.match(/Rp\s*[\d.,]+/i)) {
                    data.harga_idr = convertPriceToRupiah(safe(text));
                    break;
                }
            }
            if (data.harga_idr) break;
        }

        // Extract specs (bedrooms, bathrooms, area)
        const specsText = card.innerText || '';

        // Method 1: Look for spans with bedroom/bathroom icons (SVG-based)
        const allSpans = card.querySelectorAll('span');
        allSpans.forEach(span => {
            const text = span.innerText || span.textContent || '';
            const svg = span.querySelector('svg');

            // Check for bedroom icon (has bedroom in xlink:href)
            if (svg) {
                const use = svg.querySelector('use');
                const href = use ? (use.getAttribute('xlink:href') || use.getAttribute('href') || '') : '';

                if (href.includes('bedroom') && !data.kamar_tidur) {
                    const numMatch = text.match(/(\d+)/);
                    if (numMatch) data.kamar_tidur = parseInt(numMatch[1]);
                }

                if (href.includes('bathroom') && !data.kamar_mandi) {
                    const numMatch = text.match(/(\d+)/);
                    if (numMatch) data.kamar_mandi = parseInt(numMatch[1]);
                }
            }

            // Check for LT (Luas Tanah)
            if (text.includes('LT') && !data.luas_tanah_m2) {
                const numMatch = text.match(/(\d+)\s*m/i);
                if (numMatch) data.luas_tanah_m2 = parseInt(numMatch[1]);
            }

            // Check for LB (Luas Bangunan)
            if (text.includes('LB') && !data.luas_bangunan_m2) {
                const numMatch = text.match(/(\d+)\s*m/i);
                if (numMatch) data.luas_bangunan_m2 = parseInt(numMatch[1]);
            }
        });

        // Method 2: Fallback to regex on full text (for different formats)
        if (!data.kamar_tidur) {
            const bedMatch = specsText.match(/(\d+)\s*(?:KT|kamar tidur|bedroom)/i);
            if (bedMatch) data.kamar_tidur = parseInt(bedMatch[1]);
        }

        if (!data.kamar_mandi) {
            const bathMatch = specsText.match(/(\d+)\s*(?:KM|kamar mandi|bathroom)/i);
            if (bathMatch) data.kamar_mandi = parseInt(bathMatch[1]);
        }

        if (!data.luas_bangunan_m2) {
            // Match patterns like "LB: 55 m²" or "55 m² LB"
            const lbMatch = specsText.match(/LB\s*:?\s*(\d+)/i) || specsText.match(/(\d+)\s*m[²2]\s*LB/i);
            if (lbMatch) data.luas_bangunan_m2 = parseInt(lbMatch[1]);
        }

        if (!data.luas_tanah_m2) {
            // Match patterns like "LT: 64 m²" or "64 m² LT"
            const ltMatch = specsText.match(/LT\s*:?\s*(\d+)/i) || specsText.match(/(\d+)\s*m[²2]\s*LT/i);
            if (ltMatch) data.luas_tanah_m2 = parseInt(ltMatch[1]);
        }

        // Extract location
        const locationSelectors = [
            '[class*="location"]',
            '[class*="alamat"]',
            '[class*="address"]',
            'p[class*="text-greyText"]',
            'span[class*="text-greyText"]'
        ];

        for (const sel of locationSelectors) {
            const el = card.querySelector(sel);
            if (el) {
                const loc = safe(el.innerText || el.textContent || '');
                if (loc && loc.length < 200 && !loc.includes('Rp')) {
                    data.lokasi = loc;
                    break;
                }
            }
        }

        // Extract image
        const img = card.querySelector('img');
        if (img) {
            data.gambar = img.getAttribute('src') || img.getAttribute('data-src') || '';
            if (data.gambar.includes('srcset')) {
                const match = data.gambar.match(/(https?:\/\/[^\s]+)/);
                if (match) data.gambar = match[1].split(' ')[0];
            }
        }

        // Extract date
        const datePatterns = [
            /(\d+)\s*(menit|jam|hari|minggu|bulan|tahun)\s*(yang lalu|lalu)/i,
            /diperbarui\s+(\d+)\s*(menit|jam|hari|minggu|bulan|tahun)/i
        ];

        for (const pattern of datePatterns) {
            const match = specsText.match(pattern);
            if (match) {
                data.tanggal_terbit = convertRelativeTimeToDate(match[0]);
                break;
            }
        }

        // Extract cicilan/tenor (monthly installment info)
        const tenorSpans = card.querySelectorAll('span');
        tenorSpans.forEach(span => {
            const text = span.innerText || span.textContent || '';
            // Match pattern like "Rp 27 Jutaan (Tenor 20 Tahun)"
            if (text.includes('Tenor') && text.match(/Rp\s*\d+/i)) {
                const cleanText = safe(text);

                // Check which tenor it is
                if (text.includes('20 Tahun')) {
                    data.cicilan_20_tahun = cleanText;
                } else if (text.includes('15 Tahun')) {
                    data.cicilan_15_tahun = cleanText;
                } else if (text.includes('25 Tahun')) {
                    // If there's 25 years, put it in 20 tahun column as longest tenor
                    if (!data.cicilan_20_tahun) data.cicilan_20_tahun = cleanText;
                } else if (text.includes('10 Tahun')) {
                    // 10 years goes to 15 column as shorter option
                    if (!data.cicilan_15_tahun) data.cicilan_15_tahun = cleanText;
                }
            }
        });

    } catch (e) {
        console.warn('[Rumah123 Scraper] Error extracting card data:', e);
    }

    return data;
}

/**
 * Extract property data from all visible cards
 */
function extractCards() {
    const cards = findPropertyCards();
    const rows = [];

    console.log(`[Rumah123 Scraper] Processing ${cards.length} cards...`);

    cards.forEach((card, index) => {
        try {
            const data = extractCardData(card);

            // Validation: Ensure we have complete, useful data
            const hasTitle = data.judul && data.judul.trim().length > 0;
            const hasUrl = data.url_properti && data.url_properti.trim().length > 0;
            const hasPrice = data.harga_idr && data.harga_idr.trim().length > 0;
            const hasSpecs = data.kamar_tidur || data.kamar_mandi ||
                data.luas_bangunan_m2 || data.luas_tanah_m2;

            // Must have: title, URL, price, and at least one spec
            if (hasTitle && hasUrl && hasPrice && hasSpecs) {
                rows.push(data);
                console.log(`[Rumah123 Scraper] Card ${index}: OK - ${data.judul.substring(0, 40)}`);
            } else {
                // Log what's missing for debugging
                const missing = [];
                if (!hasTitle) missing.push('judul');
                if (!hasUrl) missing.push('url');
                if (!hasPrice) missing.push('harga');
                if (!hasSpecs) missing.push('specs');
                console.log(`[Rumah123 Scraper] Card ${index} skipped - missing: ${missing.join(', ')}`);
            }
        } catch (e) {
            console.warn(`[Rumah123 Scraper] Error parsing card ${index}:`, e);
        }
    });

    console.log(`[Rumah123 Scraper] Successfully extracted ${rows.length} complete items`);
    return rows;
}



/**
 * Auto-scroll to load all lazy-loaded content
 */
async function autoScrollToBottom() {
    const maxScrollRounds = 30;
    const scrollPause = 500;
    const stableRoundsToStop = 3;

    let lastHeight = -1;
    let stable = 0;

    console.log('[Rumah123 Scraper] Starting auto-scroll...');

    for (let i = 0; i < maxScrollRounds; i++) {
        if (!isScrapingActive) break;

        // Scroll down
        window.scrollBy(0, Math.floor(window.innerHeight * 0.8));

        await new Promise(resolve => setTimeout(resolve, scrollPause));

        // Check if height changed
        const currentHeight = document.body.scrollHeight || document.documentElement.scrollHeight;
        if (currentHeight === lastHeight) {
            stable++;
        } else {
            stable = 0;
            lastHeight = currentHeight;
        }

        if (stable >= stableRoundsToStop) {
            console.log('[Rumah123 Scraper] Scroll complete - page fully loaded');
            break;
        }
    }

    // Scroll back to top
    window.scrollTo(0, 0);
}

/**
 * Scrape current page
 */
async function scrapeCurrentPage() {
    console.log('[Rumah123 Scraper] Starting page scrape...');

    // Wait a bit for content to load
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Scroll to load all content
    await autoScrollToBottom();

    // Small delay after scrolling
    await new Promise(resolve => setTimeout(resolve, 500));

    // Extract cards
    const rows = extractCards();

    return rows;
}

/**
 * Message listener for communication with popup/background
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[Rumah123 Scraper] Received message:', request.action);

    switch (request.action) {
        case 'ping':
            sendResponse({ success: true, message: 'Content script ready' });
            break;

        case 'startScraping':
            isScrapingActive = true;
            scrapeCurrentPage().then(data => {
                console.log('[Rumah123 Scraper] Scraping complete, found:', data.length);
                sendResponse({ success: true, data: data });
            }).catch(err => {
                console.error('[Rumah123 Scraper] Scraping error:', err);
                sendResponse({ success: false, error: err.message });
            });
            return true; // Keep channel open for async response

        case 'stopScraping':
            isScrapingActive = false;
            sendResponse({ success: true, message: 'Scraping stopped' });
            break;

        case 'getCardCount':
            const cards = findPropertyCards();
            sendResponse({ success: true, count: cards.length });
            break;

        case 'getCurrentPageData':
            const cardData = extractCards();
            sendResponse({ success: true, data: cardData });
            break;

        default:
            sendResponse({ success: false, error: 'Unknown action' });
    }

    return false;
});

// Notify that content script is ready
console.log('[Rumah123 Scraper] Content script loaded on:', window.location.href);

// Log available cards on page load
setTimeout(() => {
    const cards = findPropertyCards();
    console.log(`[Rumah123 Scraper] Page loaded - detected ${cards.length} property cards`);
}, 2000);
