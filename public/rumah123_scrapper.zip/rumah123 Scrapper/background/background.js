/**
 * Background Service Worker for Rumah123 Scraper
 * Simple single-session scraping with API tracking
 */

// API Configuration
const API_BASE_URL = 'https://api.athuridha.my.id';

// Single scraping state
let scrapingState = {
    isActive: false,
    collectedData: [],
    targetCount: 50,
    currentPage: 1,
    existingUrls: new Set()
};

// Usage state (for display only - does not block scraping)
let usageState = {
    deviceId: null,
    licenseKey: null,
    hasLicense: false,
    plan: 'free',
    dailyLimit: 500,
    usedToday: 0,
    remaining: 500
};

/**
 * Generate unique device ID
 */
function generateDeviceId() {
    return 'DEV-' + Date.now().toString(36) + '-' + Math.random().toString(36).substr(2, 9);
}

/**
 * Get device ID (Singleton pattern to prevent race conditions)
 */
let _deviceIdPromise = null;

async function getDeviceId() {
    // Return existing promise if already in progress (prevents race condition)
    if (_deviceIdPromise) return _deviceIdPromise;

    _deviceIdPromise = (async () => {
        // 1. Check memory first
        if (usageState.deviceId) {
            console.log('[Background] Using cached deviceId:', usageState.deviceId);
            return usageState.deviceId;
        }

        // 2. Check Local Storage
        console.log('[Background] Checking local storage for deviceId...');
        let local = await chrome.storage.local.get('deviceId');
        if (local.deviceId) {
            console.log('[Background] Found deviceId in local:', local.deviceId);
            usageState.deviceId = local.deviceId;
            return local.deviceId;
        }

        // 3. Check Sync Storage (backup)
        console.log('[Background] Checking sync storage for deviceId...');
        let sync = await chrome.storage.sync.get('deviceId');
        if (sync.deviceId) {
            console.log('[Background] Found deviceId in sync:', sync.deviceId);
            usageState.deviceId = sync.deviceId;
            await chrome.storage.local.set({ deviceId: sync.deviceId });
            return sync.deviceId;
        }

        // 4. Generate NEW (only for truly new users)
        const newId = generateDeviceId();
        console.log('[Background] GENERATING NEW Device ID:', newId);

        // Save to BOTH storages immediately
        await chrome.storage.local.set({ deviceId: newId });
        await chrome.storage.sync.set({ deviceId: newId });

        usageState.deviceId = newId;
        return newId;
    })();

    return _deviceIdPromise;
}

/**
 * Track usage with API and check if allowed (ENFORCES LIMIT)
 * Returns { allowed: boolean, remaining: number, error?: string }
 */
async function trackUsageWithLimit(count) {
    try {
        const deviceId = await getDeviceId();
        const local = await chrome.storage.local.get('license_key');

        console.log('[Background] Tracking usage...', { deviceId, count });

        const payload = {
            deviceId,
            licenseKey: local.license_key || null,
            count,
            userAgent: navigator.userAgent
        };

        const response = await fetch(`${API_BASE_URL}/api/license/use`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();
        console.log('[Background] API Response:', data);

        if (data.success) {
            usageState.usedToday = data.used;
            usageState.remaining = data.remaining;
            usageState.plan = data.plan;

            // Sync usage state to storage so popup can see it immediately
            await chrome.storage.local.set({ usageState: usageState });

            return { allowed: true, remaining: data.remaining };
        } else {
            return { allowed: false, remaining: 0, error: data.error || 'Limit tercapai' };
        }
    } catch (e) {
        console.warn('[Background] Usage tracking failed:', e.message);
        return { allowed: true, remaining: usageState.remaining, error: 'Offline mode' };
    }
}

/**
 * Check usage status with API
 */
async function checkUsage() {
    try {
        const deviceId = await getDeviceId();
        const local = await chrome.storage.local.get('license_key');

        const payload = { deviceId };
        if (local.license_key) payload.licenseKey = local.license_key;

        const response = await fetch(`${API_BASE_URL}/api/client/config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await response.json();
        if (data.success) {
            usageState = {
                ...usageState,
                deviceId: deviceId, // Ensure deviceId is synced
                hasLicense: data.user.type === 'license',
                plan: data.user.plan || 'free',
                dailyLimit: data.user.limit,
                usedToday: data.user.usage,
                remaining: data.user.limit - data.user.usage
            };
            await chrome.storage.local.set({ usageState: usageState });
            return { success: true, usage: usageState };
        }
    } catch (e) {
        console.warn('[Background] Usage check failed:', e.message);
    }
    return { success: false, usage: usageState };
}

/**
 * Filter duplicates based on URL
 */
function filterDuplicates(rows) {
    const newRows = [];
    let duplicates = 0;

    for (const row of rows) {
        const url = row.url_properti?.trim();
        if (url && !scrapingState.existingUrls.has(url)) {
            newRows.push(row);
            scrapingState.existingUrls.add(url);
        } else {
            duplicates++;
        }
    }

    return { newRows, duplicates };
}

/**
 * Convert data to CSV format
 */
function convertToCSV(data) {
    if (data.length === 0) return '';

    const headers = [
        'Judul',
        'URL Properti',
        'Harga (IDR)',
        'Cicilan 20 Tahun',
        'Cicilan 15 Tahun',
        'Jumlah Kamar Tidur',
        'Jumlah Kamar Mandi',
        'Luas Bangunan (m2)',
        'Luas Tanah (m2)',
        'Lokasi',
        'Gambar Properti',
        'Tanggal Terbit'
    ];

    const rows = data.map(row => [
        `"${(row.judul || '').replace(/"/g, '""')}"`,
        `"${(row.url_properti || '').replace(/"/g, '""')}"`,
        `"${(row.harga_idr || '').replace(/"/g, '""')}"`,
        `"${(row.cicilan_20_tahun || '').replace(/"/g, '""')}"`,
        `"${(row.cicilan_15_tahun || '').replace(/"/g, '""')}"`,
        row.kamar_tidur || '',
        row.kamar_mandi || '',
        row.luas_bangunan_m2 || '',
        row.luas_tanah_m2 || '',
        `"${(row.lokasi || '').replace(/"/g, '""')}"`,
        `"${(row.gambar || '').replace(/"/g, '""')}"`,
        `"${(row.tanggal_terbit || '').replace(/"/g, '""')}"`
    ].join(','));

    return [headers.join(','), ...rows].join('\n');
}

/**
 * Download file
 */
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);

    chrome.downloads.download({
        url: url,
        filename: filename,
        saveAs: true
    }, () => {
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
}

/**
 * Save state to Chrome storage
 */
async function saveState() {
    await chrome.storage.local.set({
        scrapingState: {
            isActive: scrapingState.isActive,
            collectedData: scrapingState.collectedData,
            targetCount: scrapingState.targetCount,
            currentPage: scrapingState.currentPage,
            existingUrls: Array.from(scrapingState.existingUrls)
        }
    });
}

/**
 * Load state from Chrome storage
 */
async function loadState() {
    const result = await chrome.storage.local.get('scrapingState');
    if (result.scrapingState) {
        scrapingState = {
            ...result.scrapingState,
            existingUrls: new Set(result.scrapingState.existingUrls || [])
        };
    }
}

/**
 * Message listener
 */
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('[Background] Received:', request.action);

    switch (request.action) {
        case 'getState':
            loadState().then(() => {
                sendResponse({
                    success: true,
                    state: {
                        isActive: scrapingState.isActive,
                        collectedCount: scrapingState.collectedData.length,
                        targetCount: scrapingState.targetCount,
                        currentPage: scrapingState.currentPage
                    }
                });
            });
            return true;

        case 'updateSettings':
            scrapingState.targetCount = request.targetCount || scrapingState.targetCount;
            saveState();
            sendResponse({ success: true });
            break;

        case 'startScraping':
            scrapingState.isActive = true;
            saveState();
            sendResponse({ success: true });
            break;

        case 'stopScraping':
            scrapingState.isActive = false;
            saveState();
            sendResponse({ success: true });
            break;

        case 'addData':
            (async () => {
                const { newRows, duplicates } = filterDuplicates(request.data || []);
                const needed = scrapingState.targetCount - scrapingState.collectedData.length;
                const toAdd = newRows.slice(0, needed);

                console.log(`[Background] Adding data: ${toAdd.length} rows (duplicates: ${duplicates})`);

                if (toAdd.length === 0) {
                    sendResponse({
                        success: true,
                        added: 0,
                        duplicates: duplicates,
                        total: scrapingState.collectedData.length
                    });
                    return;
                }

                // Call API to track usage - this enforces the limit
                console.log('[Background] Calling trackUsageWithLimit for count:', toAdd.length);
                const usageResult = await trackUsageWithLimit(toAdd.length);
                console.log('[Background] Usage result:', usageResult);

                if (!usageResult.allowed) {
                    // Server says limit exceeded
                    sendResponse({
                        success: false,
                        error: usageResult.error || 'Limit harian tercapai! Upgrade ke Pro.',
                        limitReached: true
                    });
                    return;
                }

                // Server approved - add data
                scrapingState.collectedData.push(...toAdd);
                saveState();
                sendResponse({
                    success: true,
                    added: toAdd.length,
                    duplicates: duplicates,
                    total: scrapingState.collectedData.length,
                    remaining: usageResult.remaining
                });
            })();
            return true;

        case 'clearData':
            scrapingState.collectedData = [];
            scrapingState.existingUrls = new Set();
            scrapingState.currentPage = 1;
            scrapingState.isActive = false;
            saveState();
            sendResponse({ success: true });
            break;

        case 'exportCSV':
            const csv = convertToCSV(scrapingState.collectedData);
            const csvFilename = `rumah123_${Date.now()}.csv`;
            downloadFile(csv, csvFilename, 'text/csv');
            sendResponse({ success: true });
            break;

        case 'exportJSON':
            const json = JSON.stringify(scrapingState.collectedData, null, 2);
            const jsonFilename = `rumah123_${Date.now()}.json`;
            downloadFile(json, jsonFilename, 'application/json');
            sendResponse({ success: true });
            break;

        case 'getAllData':
            loadState().then(() => {
                sendResponse({
                    success: true,
                    data: scrapingState.collectedData
                });
            });
            return true;

        default:
            sendResponse({ success: false, error: 'Unknown action' });
    }

    return true; // Keep message channel open for async responses
});

// Auto-continue scraping on page load (WITH TRACKING)
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.includes('rumah123.com')) {
        await loadState();

        if (scrapingState.isActive) {
            console.log('[Background] Auto-continue scraping...');

            setTimeout(async () => {
                try {
                    const response = await chrome.tabs.sendMessage(tabId, { action: 'startScraping' });

                    if (response && response.success && response.data) {
                        const { newRows, duplicates } = filterDuplicates(response.data);
                        const needed = scrapingState.targetCount - scrapingState.collectedData.length;
                        const toAdd = newRows.slice(0, needed);

                        if (toAdd.length > 0) {
                            // TRACK USAGE ENFORCEMENT
                            const usageResult = await trackUsageWithLimit(toAdd.length);

                            if (!usageResult.allowed) {
                                console.log('[Background] Limit reached during auto-scrape. Stopping.');
                                scrapingState.isActive = false;
                                await saveState();
                                return;
                            }

                            scrapingState.collectedData.push(...toAdd);
                            await saveState();

                            console.log(`[Background] Added ${toAdd.length} items, total: ${scrapingState.collectedData.length}, remaining limit: ${usageResult.remaining}`);
                        } else {
                            console.log(`[Background] No new items (duplicates: ${duplicates})`);
                        }

                        if (scrapingState.collectedData.length >= scrapingState.targetCount) {
                            console.log('[Background] Target reached!');
                            scrapingState.isActive = false;
                            await saveState();
                        } else {
                            // Navigate to next page
                            setTimeout(async () => {
                                await loadState();
                                if (scrapingState.isActive) {
                                    try {
                                        const url = new URL(tab.url);
                                        const currentPage = parseInt(url.searchParams.get('page') || '1');
                                        url.searchParams.set('page', (currentPage + 1).toString());
                                        console.log(`[Background] Going to page ${currentPage + 1}`);
                                        chrome.tabs.update(tabId, { url: url.toString() });
                                    } catch (e) {
                                        console.log('[Background] Navigation error:', e.message);
                                    }
                                }
                            }, 2000);
                        }
                    }
                } catch (e) {
                    console.log('[Background] Error:', e.message);
                }
            }, 2500);
        }
    }
});

// Initialize
chrome.runtime.onInstalled.addListener(async () => {
    console.log('[Rumah123 Scraper] Extension installed');
    await loadState();
    await getDeviceId(); // Ensure ID is generated immediately
});

chrome.runtime.onStartup.addListener(async () => {
    await loadState();
    await getDeviceId(); // Ensure ID is available for popup
});

// Also generate ID immediately when service worker starts
(async () => {
    await getDeviceId();
    console.log('[Rumah123 Scraper] Background service worker started, Device ID ready');
})();

