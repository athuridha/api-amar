/**
 * Popup JavaScript for Rumah123 Scraper Extension
 * With License Management and API Tracking
 */

// API Configuration
const API_BASE_URL = 'https://api.athuridha.my.id';

// DOM Elements
const elements = {
    currentUrl: document.getElementById('currentUrl'),
    detectedInfo: document.getElementById('detectedInfo'),
    target: document.getElementById('target'),
    collectedCount: document.getElementById('collectedCount'),
    targetDisplay: document.getElementById('targetDisplay'),
    currentPage: document.getElementById('currentPage'),
    progressBar: document.getElementById('progressBar'),
    progressText: document.getElementById('progressText'),
    statusIndicator: document.getElementById('statusIndicator'),
    btnScrapeAll: document.getElementById('btnScrapeAll'),
    btnScrapeThis: document.getElementById('btnScrapeThis'),
    btnStop: document.getElementById('btnStop'),
    btnNextPage: document.getElementById('btnNextPage'),
    btnClear: document.getElementById('btnClear'),
    btnExportCSV: document.getElementById('btnExportCSV'),
    btnExportJSON: document.getElementById('btnExportJSON'),
    logContainer: document.getElementById('logContainer'),
    notOnSite: document.getElementById('notOnSite'),
    mainContent: document.getElementById('mainContent'),
    // License elements
    apiStatus: document.getElementById('apiStatus'),
    licenseSection: document.getElementById('licenseSection'),
    licenseStatus: document.getElementById('licenseStatus'),
    licenseForm: document.getElementById('licenseForm'),
    licenseInfo: document.getElementById('licenseInfo'),
    licenseKey: document.getElementById('licenseKey'),
    btnActivate: document.getElementById('btnActivate'),
    btnLogout: document.getElementById('btnLogout'),
    licensePlan: document.getElementById('licensePlan'),
    licenseRemaining: document.getElementById('licenseRemaining')
};

// State
let currentTabUrl = '';
let detectedParams = { mode: '', lokasi: '', tipe: '', page: 1 };
let usageState = null;

/**
 * Set API Status indicator
 */
function setApiStatus(status) {
    if (!elements.apiStatus) return;
    elements.apiStatus.className = 'api-status ' + status;
    const text = elements.apiStatus.querySelector('.api-text');
    if (text) {
        text.textContent = status === 'connected' ? 'API ✓' : (status === 'connecting' ? 'API...' : 'API ✗');
    }
}

/**
 * Check usage with API (With retry mechanism)
 */
async function checkUsage(retryCount = 0) {
    setApiStatus('connecting');

    // Show loading status
    if (elements.licenseStatus) {
        elements.licenseStatus.innerHTML = '<div class="license-free">Mengecek status...</div>';
    }

    try {
        // Get ID from shared storage
        const stored = await chrome.storage.local.get(['deviceId', 'license_key']);
        let deviceId = stored.deviceId;

        // Show ID in footer
        const idDisplay = document.getElementById('deviceIdDisplay');
        if (idDisplay) idDisplay.textContent = deviceId || 'Generating...';

        if (!deviceId) {
            console.warn('Device ID not found. Retry:', retryCount);

            // Retry up to 3 times
            if (retryCount < 3) {
                await new Promise(r => setTimeout(r, 500));
                return checkUsage(retryCount + 1);
            }

            // Show error after retries
            if (elements.licenseStatus) {
                elements.licenseStatus.innerHTML = '<div class="license-invalid">Gagal memuat. Reload extension.</div>';
            }
            setApiStatus('disconnected');
            return false;
        }

        const licenseKey = stored.license_key;
        const payload = { deviceId };
        if (licenseKey) payload.licenseKey = licenseKey;

        const res = await fetch(`${API_BASE_URL}/api/client/config`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const data = await res.json();
        if (data.success) {
            setApiStatus('connected');
            usageState = {
                hasLicense: data.user.type === 'license',
                plan: data.user.plan || 'Free',
                dailyLimit: data.user.limit,
                remaining: data.user.limit - data.user.usage,
                usedToday: data.user.usage
            };
            updateUsageUI();
            if (idDisplay) idDisplay.textContent = deviceId;
            return true;
        } else {
            throw new Error(data.error || 'API Error');
        }
    } catch (e) {
        console.error('Usage check failed:', e);
        if (elements.licenseStatus) {
            elements.licenseStatus.innerHTML = '<div class="license-invalid">Koneksi API gagal</div>';
        }
    }
    setApiStatus('disconnected');
    return false;
}

/**
 * Update usage UI
 */
function updateUsageUI() {
    if (!usageState) return;

    const planLabel = usageState.hasLicense ? usageState.plan.toUpperCase() : 'FREE';
    const limitLabel = usageState.dailyLimit >= 999999 ? 'Unlimited' : usageState.dailyLimit;

    if (elements.licensePlan) elements.licensePlan.textContent = planLabel;
    if (elements.licenseRemaining) {
        elements.licenseRemaining.textContent = usageState.dailyLimit >= 999999
            ? `${usageState.usedToday} used`
            : `${usageState.remaining} / ${limitLabel}`;
    }

    if (usageState.hasLicense) {
        if (elements.licenseForm) elements.licenseForm.style.display = 'none';
        if (elements.licenseInfo) elements.licenseInfo.style.display = 'flex';
        if (elements.btnLogout) elements.btnLogout.style.display = 'block';
        if (elements.licenseStatus) elements.licenseStatus.innerHTML = `<div class="license-valid">License ${planLabel} Aktif</div>`;
    } else {
        if (elements.licenseForm) elements.licenseForm.style.display = 'flex';
        if (elements.licenseInfo) elements.licenseInfo.style.display = 'flex';
        if (elements.btnLogout) elements.btnLogout.style.display = 'none';
        if (elements.licenseStatus) elements.licenseStatus.innerHTML = `<div class="license-free">Mode Free (${usageState.remaining} limit tersisa)</div>`;
    }

    if (usageState.remaining <= 0 && usageState.dailyLimit < 999999) {
        if (elements.licenseStatus) elements.licenseStatus.innerHTML = `<div class="license-invalid">Limit tercapai! Upgrade ke Pro.</div>`;
        if (elements.licenseForm) elements.licenseForm.style.display = 'flex';
    }
}

/**
 * Activate license key
 */
async function activateLicense() {
    const key = elements.licenseKey?.value?.trim();
    if (!key) {
        log('Masukkan license key', 'error');
        return;
    }

    if (elements.btnActivate) {
        elements.btnActivate.disabled = true;
        elements.btnActivate.textContent = 'Validating...';
    }
    log('Memvalidasi license...', 'info');

    try {
        const res = await fetch(`${API_BASE_URL}/api/license/check`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ licenseKey: key })
        });

        const data = await res.json();
        if (data.valid) {
            localStorage.setItem('license_key', key);
            await chrome.storage.local.set({ license_key: key });
            log(`License ${data.plan} aktif!`, 'success');
            await checkUsage();
        } else {
            log('License tidak valid: ' + (data.error || 'Unknown'), 'error');
        }
    } catch (e) {
        log('Activation failed: ' + e.message, 'error');
    }

    if (elements.btnActivate) {
        elements.btnActivate.disabled = false;
        elements.btnActivate.textContent = 'Aktivasi';
    }
}

/**
 * Logout license
 */
async function logoutLicense() {
    if (!confirm('Kembali ke mode Free?')) return;
    localStorage.removeItem('license_key');
    await chrome.storage.local.remove('license_key');
    if (elements.licenseKey) elements.licenseKey.value = '';
    await checkUsage();
    log('Logout berhasil', 'info');
}

/**
 * Log message to console UI
 */
function log(message, type = '') {
    if (!elements.logContainer) return;
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
    elements.logContainer.insertBefore(entry, elements.logContainer.firstChild);

    while (elements.logContainer.children.length > 50) {
        elements.logContainer.removeChild(elements.logContainer.lastChild);
    }
}

/**
 * Parse rumah123.com URL
 */
function parseRumah123Url(url) {
    const result = { mode: '', lokasi: '', tipe: '', page: 1, isValid: false };
    try {
        const urlObj = new URL(url);
        if (!urlObj.hostname.includes('rumah123.com')) return result;

        const pathParts = urlObj.pathname.split('/').filter(p => p);
        if (pathParts.length >= 1) {
            const mode = pathParts[0];
            if (mode === 'jual' || mode === 'sewa') {
                result.mode = mode;
                result.isValid = true;
                if (pathParts[1] === 'cari') {
                    result.lokasi = 'Search Results';
                    result.tipe = 'Mixed';
                } else if (pathParts.length >= 2) {
                    result.lokasi = pathParts[1] || '';
                    result.tipe = pathParts[2] || '';
                }
                const pageParam = urlObj.searchParams.get('page');
                if (pageParam) result.page = parseInt(pageParam) || 1;
            }
        }
    } catch (e) {
        console.error('Error parsing URL:', e);
    }
    return result;
}

function formatLocation(loc) {
    if (!loc) return '-';
    return loc.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

function updateProgress(collected, target) {
    const percent = target > 0 ? Math.min(100, Math.round((collected / target) * 100)) : 0;
    if (elements.collectedCount) elements.collectedCount.textContent = collected;
    if (elements.targetDisplay) elements.targetDisplay.textContent = target;
    if (elements.progressBar) elements.progressBar.style.width = percent + '%';
    if (elements.progressText) elements.progressText.textContent = percent + '%';
}

function updateStatus(status) {
    if (!elements.statusIndicator) return;
    elements.statusIndicator.className = 'status-indicator ' + status;
    const statusText = elements.statusIndicator.querySelector('.status-text');
    if (statusText) {
        statusText.textContent = status === 'scraping' ? 'Scraping...' : (status === 'active' ? 'Siap' : 'Idle');
    }
}

async function detectCurrentPage() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url) { showNotOnSite(); return; }

        currentTabUrl = tab.url;
        detectedParams = parseRumah123Url(currentTabUrl);

        if (!detectedParams.isValid) { showNotOnSite(); return; }

        if (elements.notOnSite) elements.notOnSite.style.display = 'none';
        if (elements.mainContent) elements.mainContent.style.display = 'block';

        const displayUrl = currentTabUrl.length > 50 ? currentTabUrl.substring(0, 50) + '...' : currentTabUrl;
        if (elements.currentUrl) {
            elements.currentUrl.textContent = displayUrl;
            elements.currentUrl.title = currentTabUrl;
        }

        if (elements.detectedInfo) {
            elements.detectedInfo.innerHTML = `
                <div class="info-item"><span class="label">Mode:</span> <span class="value">${detectedParams.mode.toUpperCase()}</span></div>
                <div class="info-item"><span class="label">Lokasi:</span> <span class="value">${formatLocation(detectedParams.lokasi)}</span></div>
                <div class="info-item"><span class="label">Tipe:</span> <span class="value">${detectedParams.tipe || 'All'}</span></div>
                <div class="info-item"><span class="label">Halaman:</span> <span class="value">${detectedParams.page}</span></div>
            `;
        }
        if (elements.currentPage) elements.currentPage.textContent = detectedParams.page;
    } catch (e) {
        console.error('Error detecting page:', e);
        showNotOnSite();
    }
}

function showNotOnSite() {
    if (elements.notOnSite) elements.notOnSite.style.display = 'block';
    if (elements.mainContent) elements.mainContent.style.display = 'none';
}

async function loadState() {
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getState' });
        if (response && response.success) {
            const state = response.state;
            if (elements.target) elements.target.value = state.targetCount;
            updateProgress(state.collectedCount, state.targetCount);
            if (state.isActive) {
                updateStatus('scraping');
                setButtonStates(true);
            } else if (state.collectedCount > 0) {
                updateStatus('active');
            }
        }
    } catch (e) {
        log('Error loading state: ' + e.message, 'error');
    }
}

function setButtonStates(isScraping) {
    if (elements.btnScrapeAll) elements.btnScrapeAll.disabled = isScraping;
    if (elements.btnScrapeThis) elements.btnScrapeThis.disabled = isScraping;
    if (elements.btnStop) elements.btnStop.disabled = !isScraping;
    if (elements.btnNextPage) elements.btnNextPage.disabled = isScraping;
    if (elements.target) elements.target.disabled = isScraping;
}

async function sendToContentScript(message) {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('No active tab');
    return chrome.tabs.sendMessage(tab.id, message);
}

async function scrapeCurrentPage() {
    log('Memulai scraping halaman...', 'info');
    setButtonStates(true);
    updateStatus('scraping');

    try {
        const response = await sendToContentScript({ action: 'startScraping' });
        if (response && response.success && response.data) {
            const addResponse = await chrome.runtime.sendMessage({
                action: 'addData',
                data: response.data
            });

            if (addResponse && addResponse.success) {
                log(`Berhasil: +${addResponse.added || 0} data (${addResponse.duplicates} duplikat)`, 'success');
                updateProgress(addResponse.total, elements.target?.value || 50);

                if (addResponse.remaining !== undefined) {
                    if (!usageState) usageState = { dailyLimit: 500 };
                    usageState.remaining = addResponse.remaining;
                    usageState.usedToday = (usageState.dailyLimit || 500) - addResponse.remaining;
                    updateUsageUI();
                }
            } else {
                log('Error: ' + (addResponse?.error || 'Unknown error'), 'error');
                if (addResponse?.limitReached && usageState) {
                    usageState.remaining = 0;
                    updateUsageUI();
                }
            }
        } else {
            log('Tidak ada data ditemukan', 'error');
        }
    } catch (e) {
        log('Error: ' + e.message, 'error');
    }

    setButtonStates(false);
    updateStatus('active');
}

async function scrapeAllPages() {
    log('Memulai scraping semua halaman...', 'info');
    await chrome.runtime.sendMessage({ action: 'startScraping' });
    setButtonStates(true);
    updateStatus('scraping');
    await scrapeCurrentPage();

    const state = await chrome.runtime.sendMessage({ action: 'getState' });
    if (state && state.success && state.state.collectedCount >= parseInt(elements.target?.value || 50)) {
        log('Target tercapai!', 'success');
        await stopScraping();
        return;
    }

    if (state && state.success && state.state.isActive) {
        log('Menuju halaman berikutnya dalam 3 detik...', 'info');
        setTimeout(goToNextPage, 3000);
    }
}

async function goToNextPage() {
    try {
        const nextPage = detectedParams.page + 1;
        const url = new URL(currentTabUrl);
        url.searchParams.set('page', nextPage.toString());
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
            await chrome.tabs.update(tab.id, { url: url.toString() });
            log(`Navigasi ke halaman ${nextPage}...`, 'info');
        }
    } catch (e) {
        log('Error navigasi: ' + e.message, 'error');
    }
}

async function stopScraping() {
    setButtonStates(false);
    updateStatus('active');
    await chrome.runtime.sendMessage({ action: 'stopScraping' });
    await sendToContentScript({ action: 'stopScraping' }).catch(() => { });
    log('Scraping dihentikan', 'info');
}

async function clearData() {
    if (!confirm('Hapus semua data yang sudah dikumpulkan?')) return;
    await chrome.runtime.sendMessage({ action: 'clearData' });
    updateProgress(0, elements.target?.value || 50);
    log('Data dihapus', 'info');
}

async function exportCSV() {
    log('Mengexport ke CSV...', 'info');
    try {
        await chrome.runtime.sendMessage({ action: 'exportCSV' });
        log('Export CSV berhasil!', 'success');
    } catch (e) {
        log('Error export: ' + e.message, 'error');
    }
}

async function exportJSON() {
    log('Mengexport ke JSON...', 'info');
    try {
        await chrome.runtime.sendMessage({ action: 'exportJSON' });
        log('Export JSON berhasil!', 'success');
    } catch (e) {
        log('Error export: ' + e.message, 'error');
    }
}

// Event Listeners
if (elements.btnScrapeAll) elements.btnScrapeAll.addEventListener('click', scrapeAllPages);
if (elements.btnScrapeThis) elements.btnScrapeThis.addEventListener('click', scrapeCurrentPage);
if (elements.btnStop) elements.btnStop.addEventListener('click', stopScraping);
if (elements.btnNextPage) elements.btnNextPage.addEventListener('click', goToNextPage);
if (elements.btnClear) elements.btnClear.addEventListener('click', clearData);
if (elements.btnExportCSV) elements.btnExportCSV.addEventListener('click', exportCSV);
if (elements.btnExportJSON) elements.btnExportJSON.addEventListener('click', exportJSON);
if (elements.btnActivate) elements.btnActivate.addEventListener('click', activateLicense);
if (elements.btnLogout) elements.btnLogout.addEventListener('click', logoutLicense);

const btnUpgrade = document.getElementById('btnUpgrade');
if (btnUpgrade) {
    btnUpgrade.addEventListener('click', () => {
        chrome.tabs.create({ url: 'https://api.athuridha.my.id/pricing' });
    });
}

if (elements.target) {
    elements.target.addEventListener('change', async () => {
        const target = parseInt(elements.target.value) || 50;
        if (elements.targetDisplay) elements.targetDisplay.textContent = target;
        await chrome.runtime.sendMessage({ action: 'updateSettings', targetCount: target });
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    await detectCurrentPage();
    await loadState();
    await checkUsage();

    const btnViewData = document.getElementById('btnViewData');
    if (btnViewData) {
        btnViewData.addEventListener('click', () => {
            chrome.tabs.create({ url: chrome.runtime.getURL('viewer/viewer.html') });
        });
    }

    // Poll for state updates
    setInterval(async () => {
        try {
            const response = await chrome.runtime.sendMessage({ action: 'getState' });
            if (response && response.success) {
                const state = response.state;
                updateProgress(state.collectedCount, state.targetCount);
                if (state.isActive) {
                    updateStatus('scraping');
                    setButtonStates(true);
                } else {
                    updateStatus('active');
                    setButtonStates(false);
                }
            }
        } catch (e) { /* ignore */ }
    }, 2000);
});

// Listen for storage changes
chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'local' && changes.scrapingState) {
        const state = changes.scrapingState.newValue;
        if (state) {
            updateProgress(state.collectedData?.length || 0, state.targetCount || 50);
            if (state.isActive) {
                updateStatus('scraping');
                setButtonStates(true);
            } else {
                updateStatus('active');
                setButtonStates(false);
            }
        }
    }
});
