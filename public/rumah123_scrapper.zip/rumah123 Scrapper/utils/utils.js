/**
 * Utility functions for Rumah123 Scraper Extension
 * Ported from Python utils.py
 */

/**
 * Clean and trim string
 * @param {string} s - Input string
 * @returns {string} - Cleaned string
 */
function safe(s) {
    return (s || '').replace(/\u200b/g, '').trim();
}

/**
 * Convert relative time text to actual date
 * Example: 'Diperbarui 12 jam yang lalu oleh' -> '25-11-2024'
 * @param {string} text - Relative time text
 * @returns {string} - Date in DD-MM-YYYY format
 */
function convertRelativeTimeToDate(text) {
    if (!text) return '';

    const now = new Date();
    const match = text.toLowerCase().match(/(\d+)\s*(menit|jam|hari|minggu|bulan|tahun)/);

    if (match) {
        const number = parseInt(match[1]);
        const unit = match[2];
        let date = new Date(now);

        switch (unit) {
            case 'menit':
                date.setMinutes(date.getMinutes() - number);
                break;
            case 'jam':
                date.setHours(date.getHours() - number);
                break;
            case 'hari':
                date.setDate(date.getDate() - number);
                break;
            case 'minggu':
                date.setDate(date.getDate() - (number * 7));
                break;
            case 'bulan':
                date.setMonth(date.getMonth() - number);
                break;
            case 'tahun':
                date.setFullYear(date.getFullYear() - number);
                break;
            default:
                return text;
        }

        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        return `${day}-${month}-${year}`;
    }

    return text;
}

/**
 * Convert price text to numeric rupiah format
 * Example: 'Rp 1,06 Miliar' -> 'Rp 1.060.000.000'
 * @param {string} text - Price text
 * @returns {string} - Formatted price
 */
function convertPriceToRupiah(text) {
    if (!text) return '';

    const textLower = text.toLowerCase();
    const numberMatch = text.match(/(\d+(?:[.,]\d+)?)/);

    if (!numberMatch) return text;

    const numberStr = numberMatch[1].replace(',', '.');
    const number = parseFloat(numberStr);

    if (isNaN(number)) return text;

    let amount;

    if (textLower.includes('miliar') || textLower.includes('milyar') || textLower.includes('billion')) {
        amount = Math.round(number * 1000000000);
    } else if (textLower.includes('juta') || textLower.includes('million')) {
        amount = Math.round(number * 1000000);
    } else if (textLower.includes('ribu') || textLower.includes('thousand') || textLower.includes('rb')) {
        amount = Math.round(number * 1000);
    } else {
        amount = Math.round(number);
    }

    // Format with thousand separators (Indonesian style with dots)
    const formatted = 'Rp ' + amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    return formatted;
}

/**
 * Build paginated URL
 * @param {string} baseUrl - Base URL
 * @param {number} page - Page number
 * @returns {string} - URL with page parameter
 */
function buildPageUrl(baseUrl, page) {
    const url = new URL(baseUrl);
    url.searchParams.set('page', page.toString());
    return url.toString();
}

/**
 * Convert slug to pretty city name
 * Example: 'jakarta-barat' -> 'Jakarta Barat'
 * @param {string} slug - URL slug
 * @returns {string} - Pretty city name
 */
function prettifyCity(slug) {
    const s = slug.trim().replace(/_/g, '-');
    const parts = s.split('-').filter(p => p);
    return parts.map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ') || s;
}

/**
 * Add random delay (for human-like behavior)
 * @param {number} base - Base delay in ms
 * @param {number} variance - Random variance in ms
 * @returns {Promise} - Promise that resolves after delay
 */
function jitter(base = 100, variance = 100) {
    const delay = base + Math.random() * variance;
    return new Promise(resolve => setTimeout(resolve, delay));
}

// Export for use in other scripts
if (typeof window !== 'undefined') {
    window.Rumah123Utils = {
        safe,
        convertRelativeTimeToDate,
        convertPriceToRupiah,
        buildPageUrl,
        prettifyCity,
        jitter
    };
}
