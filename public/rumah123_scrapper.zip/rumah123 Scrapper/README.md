# Rumah123 Scraper - Browser Extension

Chrome/Edge extension untuk mengekstrak data properti dari rumah123.com.

## ✨ Features

- 🏠 **Scrape Property Data** - Ekstrak judul, harga, lokasi, spesifikasi, gambar
- 💰 **Auto Price Conversion** - Otomatis konversi "1,06 Miliar" → "Rp 1.060.000.000"
- 📅 **Date Conversion** - Konversi "12 jam yang lalu" → tanggal aktual
- 🔄 **Auto-Scroll** - Otomatis scroll untuk load semua konten
- ⚡ **Duplicate Filter** - Filter otomatis data duplikat
- 📊 **Export CSV/JSON** - Export data ke format CSV atau JSON

## 📦 Installation

### Chrome
1. Buka `chrome://extensions/`
2. Aktifkan **Developer mode** (toggle di kanan atas)
3. Klik **Load unpacked**
4. Pilih folder `extension` ini
5. Extension siap digunakan!

### Microsoft Edge
1. Buka `edge://extensions/`
2. Aktifkan **Developer mode** (toggle di kiri bawah)
3. Klik **Load unpacked**
4. Pilih folder `extension` ini
5. Extension siap digunakan!

### Brave / Opera / Chromium lainnya
Langkah serupa seperti Chrome.

## 🚀 Cara Penggunaan

1. **Buka Extension** - Klik icon extension di toolbar browser
2. **Set Pengaturan**:
   - Mode: Jual atau Sewa
   - Lokasi: contoh `karawang`, `jakarta-barat`
   - Tipe: Rumah, Apartemen, dll
   - Target: Jumlah data yang ingin dikumpulkan
3. **Mulai Scraping**:
   - Klik **"Mulai Scraping"** untuk navigasi otomatis ke halaman target
   - Atau buka rumah123.com manual, lalu klik **"Scrape Halaman Ini"**
4. **Export Data**:
   - Klik **"Export CSV"** atau **"Export JSON"** untuk download data

## 📁 Struktur File

```
extension/
├── manifest.json        # Configuration
├── popup/
│   ├── popup.html       # UI
│   ├── popup.css        # Styles
│   └── popup.js         # Logic
├── content/
│   └── content.js       # Scraping logic
├── background/
│   └── background.js    # Service worker
├── utils/
│   └── utils.js         # Helper functions
└── icons/
    └── icon128.png      # Extension icon
```

## 🔧 Permissions

Extension ini membutuhkan permission berikut:
- `activeTab` - Akses tab yang aktif
- `storage` - Menyimpan data scraping
- `scripting` - Menjalankan script di halaman
- `downloads` - Download file export
- `*://www.rumah123.com/*` - Akses ke rumah123.com

## ⚠️ Catatan

- Extension ini hanya berfungsi di domain `rumah123.com`
- Gunakan dengan bijak dan patuhi Terms of Service rumah123.com
- Extension ini untuk tujuan edukasi dan riset data

## 📄 License

MIT License - Lihat file LICENSE di root folder.
