/**
 * Data Viewer JavaScript
 * MacOS Style with Pagination
 */

// Default column names
const defaultColumns = {
    judul: 'Judul',
    url_properti: 'URL Properti',
    harga_idr: 'Harga (IDR)',
    cicilan_20_tahun: 'Cicilan 20 Tahun',
    cicilan_15_tahun: 'Cicilan 15 Tahun',
    kamar_tidur: 'Kamar Tidur',
    kamar_mandi: 'Kamar Mandi',
    luas_bangunan_m2: 'Luas Bangunan (m²)',
    luas_tanah_m2: 'Luas Tanah (m²)',
    lokasi: 'Lokasi',
    gambar: 'Gambar',
    tanggal_terbit: 'Tanggal Terbit'
};

// Current column names (can be edited)
let columnNames = { ...defaultColumns };
let scrapedData = [];
// Pagination State
let currentPage = 1;
const ITEMS_PER_PAGE = 30;

/**
 * Load data from Chrome storage
 */
async function loadData() {
    try {
        const response = await chrome.runtime.sendMessage({ action: 'getAllData' });

        if (response.success) {
            scrapedData = response.data || [];
        }

        const result = await chrome.storage.local.get('columnNames');
        if (result.columnNames) {
            columnNames = { ...defaultColumns, ...result.columnNames };
        }

        renderColumnInputs();
        // Reset to page 1 on load
        currentPage = 1;
        renderTable();
        updateStats();

    } catch (e) {
        console.error('Error loading data:', e);
    }
}

/**
 * Save column names to storage
 */
async function saveColumnNames() {
    try {
        await chrome.storage.local.set({ columnNames });
    } catch (e) {
        console.error('Error saving column names:', e);
    }
}

/**
 * Render column name input fields
 */
function renderColumnInputs() {
    const container = document.getElementById('columnInputs');
    container.innerHTML = '';

    Object.keys(defaultColumns).forEach(key => {
        const div = document.createElement('div');
        div.className = 'column-input';
        div.innerHTML = `
            <label>${key}</label>
            <input type="text" data-column="${key}" value="${columnNames[key]}" placeholder="${defaultColumns[key]}">
        `;
        container.appendChild(div);
    });

    container.querySelectorAll('input').forEach(input => {
        input.addEventListener('change', (e) => {
            const key = e.target.dataset.column;
            columnNames[key] = e.target.value || defaultColumns[key];
            saveColumnNames();
            renderTableHeader();
        });
    });
}

/**
 * Render table header
 */
function renderTableHeader() {
    const thead = document.getElementById('tableHead');
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <th width="50">#</th>
        ${Object.keys(defaultColumns).map(key => `<th>${columnNames[key]}</th>`).join('')}
        <th width="50">Aksi</th>
    `;
    thead.innerHTML = '';
    thead.appendChild(tr);
}

/**
 * Render data table with Pagination
 */
function renderTable() {
    const tbody = document.getElementById('tableBody');
    const emptyState = document.getElementById('emptyState');
    const table = document.getElementById('dataTable');

    renderTableHeader();

    if (scrapedData.length === 0) {
        emptyState.style.display = 'flex';
        table.style.display = 'none';
        updatePaginationControls();
        return;
    }

    emptyState.style.display = 'none';
    table.style.display = 'table';

    // Pagination Logic
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;
    const pageData = scrapedData.slice(startIndex, endIndex);

    tbody.innerHTML = pageData.map((row, index) => {
        const actualIndex = startIndex + index;
        return `
        <tr data-index="${actualIndex}">
            <td>${actualIndex + 1}</td>
            <td title="${row.judul || ''}"><strong>${(row.judul || '-').substring(0, 50)}</strong></td>
            <td class="cell-url"><a href="${row.url_properti || '#'}" target="_blank" title="${row.url_properti || ''}">Link</a></td>
            <td>${row.harga_idr || '-'}</td>
            <td title="${row.cicilan_20_tahun || ''}">${(row.cicilan_20_tahun || '-').substring(0, 25)}</td>
            <td title="${row.cicilan_15_tahun || ''}">${(row.cicilan_15_tahun || '-').substring(0, 25)}</td>
            <td>${row.kamar_tidur || '-'}</td>
            <td>${row.kamar_mandi || '-'}</td>
            <td>${row.luas_bangunan_m2 || '-'}</td>
            <td>${row.luas_tanah_m2 || '-'}</td>
            <td title="${row.lokasi || ''}">${(row.lokasi || '-').substring(0, 30)}</td>
            <td class="cell-image">${row.gambar ? `<img src="${row.gambar}" alt="property">` : '-'}</td>
            <td>${row.tanggal_terbit || '-'}</td>
            <td class="row-actions">
                <button class="btn-icon" onclick="deleteRow(${actualIndex})" title="Hapus">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 6L6 18M6 6l12 12"></path>
                    </svg>
                </button>
            </td>
        </tr>
    `}).join('');

    updatePaginationControls();
}

/**
 * Update Pagination UI Controls
 */
function updatePaginationControls() {
    const totalPages = Math.ceil(scrapedData.length / ITEMS_PER_PAGE);
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE + 1;
    const endIndex = Math.min(currentPage * ITEMS_PER_PAGE, scrapedData.length);

    const infoText = scrapedData.length > 0
        ? `Menampilkan ${startIndex} - ${endIndex} dari ${scrapedData.length} data`
        : '0 data';

    document.getElementById('paginationInfo').textContent = infoText;

    const btnPrev = document.getElementById('btnPrevPage');
    const btnNext = document.getElementById('btnNextPage');

    btnPrev.disabled = currentPage === 1;
    btnNext.disabled = currentPage === totalPages || totalPages === 0;
}

/**
 * Handle Page Changes
 */
function prevPage() {
    if (currentPage > 1) {
        currentPage--;
        renderTable();
        document.querySelector('.table-wrapper').scrollTop = 0;
    }
}

function nextPage() {
    const totalPages = Math.ceil(scrapedData.length / ITEMS_PER_PAGE);
    if (currentPage < totalPages) {
        currentPage++;
        renderTable();
        document.querySelector('.table-wrapper').scrollTop = 0;
    }
}

/**
 * Update stats display
 */
function updateStats() {
    document.getElementById('totalCount').textContent = scrapedData.length;
}

/**
 * Delete a single row
 */
async function deleteRow(index) {
    if (!confirm('Hapus data ini?')) return;
    scrapedData.splice(index, 1);

    // Check if page became empty
    const totalPages = Math.ceil(scrapedData.length / ITEMS_PER_PAGE);
    if (currentPage > totalPages && currentPage > 1) {
        currentPage = totalPages;
    }

    renderTable();
    updateStats();
}

/**
 * Convert data to CSV
 */
function convertToCSV(data) {
    if (data.length === 0) return '';

    const headers = Object.keys(defaultColumns).map(key => columnNames[key]);
    const rows = data.map(row =>
        Object.keys(defaultColumns).map(key => {
            const value = row[key] || '';
            const escaped = String(value).replace(/"/g, '""');
            return escaped.includes(',') || escaped.includes('\n') ? `"${escaped}"` : escaped;
        }).join(',')
    );

    return [headers.join(','), ...rows].join('\n');
}

/**
 * Convert data to JSON
 */
function convertToJSON(data) {
    const transformed = data.map(row => {
        const newRow = {};
        Object.keys(defaultColumns).forEach(key => {
            newRow[columnNames[key]] = row[key];
        });
        return newRow;
    });
    return JSON.stringify(transformed, null, 2);
}

/**
 * Download file
 */
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Event Listeners
document.getElementById('btnExportCSV').addEventListener('click', () => {
    if (scrapedData.length === 0) {
        alert('Tidak ada data untuk di-export');
        return;
    }
    const csv = convertToCSV(scrapedData);
    const filename = `rumah123_${Date.now()}.csv`;
    downloadFile(csv, filename, 'text/csv');
});

document.getElementById('btnExportJSON').addEventListener('click', () => {
    if (scrapedData.length === 0) {
        alert('Tidak ada data untuk di-export');
        return;
    }
    const json = convertToJSON(scrapedData);
    const filename = `rumah123_${Date.now()}.json`;
    downloadFile(json, filename, 'application/json');
});

document.getElementById('btnRefresh').addEventListener('click', () => {
    loadData();
});

document.getElementById('btnClear').addEventListener('click', async () => {
    if (!confirm('Hapus semua data? Tindakan ini tidak dapat dibatalkan.')) return;

    await chrome.runtime.sendMessage({ action: 'clearData' });
    scrapedData = [];
    currentPage = 1;
    renderTable();
    updateStats();
});

document.getElementById('btnPrevPage').addEventListener('click', prevPage);
document.getElementById('btnNextPage').addEventListener('click', nextPage);

// Initialize
document.addEventListener('DOMContentLoaded', loadData);
